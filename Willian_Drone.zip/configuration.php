<?php
$host = 'localhost';
$user = 'root';
$password = '';
$db = 'willian_drone';
?>
